import './Register.css';
import { useState } from 'react';
import { _userapiurl } from '../../APIUrls';
import axios from 'axios';

function Register() {

  const [ name , setName ] = useState();
  const [ email , setEmail ] = useState();    
  const [ password , setPassword ] = useState();
  const [ mobile , setMobile ] = useState();
  const [ address , setAddress ] = useState();
  const [ city , setCity ] = useState();
  const [ gender , setGender ] = useState();
  const [ output , setOutput ] = useState();

  

  const handlesubmit=()=>{

    const userDetails={"name":name,"email":email,"password":password,"mobile":mobile,"address":address,"city":city,"gender":gender};

    axios.post(_userapiurl+"save",userDetails).then((response)=>{
        setOutput("User register successfully....");
        setName("");
        setEmail("");
        setPassword("");
        setMobile("");
        setAddress("");
        setCity("");
    }).catch((error)=>{
        setOutput("User registration failed....");    
    });
  
 };

  



  return (
    <>
        {/* About Start */}
        {/* <div class="container-fluid ">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
            <div class="col-12 text-center">
                <h2 class="mb-5">Connect with<span> Tenders</span></h2>
                <h4 class="mb-5">Register <span>Here</span></h4>
            </div>
<font color="blue">{output}</font>
<form>
  <div class="form-group">
    <label for="name">Name:</label>
    <input type="text" class="form-control" value={name} onChange={ e => setName(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" value={email} onChange={ e => setEmail(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" value={password} onChange={ e => setPassword(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="mobile">Mobile:</label>
    <input type="text" class="form-control" value={mobile} onChange={ e => setMobile(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="address">Address:</label>
    <textarea rows="5" class="form-control" value={address} onChange={ e => setAddress(e.target.value) } ></textarea>
  </div>
  <br/>
  <div class="form-group">
    <label for="city">City:</label>
    <select class="form-control" value={city} onChange={ e => setCity(e.target.value) } >
        <option>Select City</option>
        <option>Indore</option>
        <option>Bhopal</option>
        <option>Ujjain</option>
    </select>
  </div>
  <br/>
  <div class="form-group">
    <label for="gender">Gender:</label>
    &nbsp;&nbsp;
    Male <input type="radio" name="gender" value="male" onChange={ e => setGender(e.target.value) } /> &nbsp;&nbsp;
    Female <input type="radio" name="gender" value="female" onChange={ e => setGender(e.target.value) } />
  </div>
  <br/>
  <button type="button" class="btn btn-success" onClick={ ()=> handlesubmit() }>Submit</button>
  <br />
  <br />
  <br />  
</form>
            </div>
        </div>
    </div> */}
    {/* About End */}



    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <h2 class="text-center text-dark mt-5">Register Here</h2>
        {/* <div class="text-center mb-5 text-dark">Made with bootstrap</div> */}
        <div class="card my-5">

        <font color="green">{output}</font>

          <form class="card-body cardbody-color p-lg-5">

            <div class="mb-3">
            <label for="name">Name:</label>
            <input type="text" class="form-control" value={name} onChange={ e => setName(e.target.value) } />
            </div>
            
            <div class="mb-3">
            <label for="email">Email address:</label>
            <input type="email" class="form-control" value={email} onChange={ e => setEmail(e.target.value) } />
            </div>

            <div class="mb-3">
            <label for="pwd">Password:</label>
    <input type="password" class="form-control" value={password} onChange={ e => setPassword(e.target.value) } />
            </div>

            <div class="mb-3">
            <label for="mobile">Mobile:</label>
    <input type="text" class="form-control" value={mobile} onChange={ e => setMobile(e.target.value) } />
            </div>

            <div class="mb-3">
            <label for="address">Address:</label>
    <textarea rows="5" class="form-control" value={address} onChange={ e => setAddress(e.target.value) } ></textarea>
            </div>

            <div class="mb-3">
            <label for="city">City:</label>
    <select class="form-control" value={city} onChange={ e => setCity(e.target.value) } >
        <option>Select City</option>
        <option>Indore</option>
        <option>Bhopal</option>
        <option>Ujjain</option>
    </select>
            </div>

            <div class="mb-3">
            <label for="gender">Gender:</label>
    &nbsp;&nbsp;
    Male <input type="radio" name="gender" value="male" onChange={ e => setGender(e.target.value) } /> &nbsp;&nbsp;
    Female <input type="radio" name="gender" value="female" onChange={ e => setGender(e.target.value) } />
            </div>



            <div class="text-center"><button type="button" class="btn btn-success" onClick={ ()=> handlesubmit() }>Submit</button></div>
           
          </form>
        </div>

      </div>
    </div>
  </div>


    </>
   );
}

export default Register;