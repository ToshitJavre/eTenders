import './Addcategory.css';
import { useState } from 'react';
import axios from 'axios';
import { _categoryapiurl } from '../../APIUrls';

function Addcategory() {

  const [file, setFile] = useState();
  const [catName , setCatName] = useState();
  const [output , setOutput] = useState();  

  const handleChange=(event)=>{
    setFile(event.target.files[0]);
  }

  const handleSubmit=(event)=>{
    event.preventDefault();
    var formData = new FormData();
    formData.append('catnm', catName);
    formData.append('caticon', file);
    const config = {
        'content-type': 'multipart/form-data'
    };
    axios.post(_categoryapiurl+"save", formData, config).then((response) => {
      setCatName("");
      setOutput("Category Added Successfully....");
    });
  }

  return (
    <>
        {/* About Start */}
        <div class="container-fluid ">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
              
                <div class="col-12 text-center">
       <h2 class="mb-5">Add <span>Category</span></h2>
       <h2 class="mb-5">Add <span>Category</span></h2>
    </div>
<font style={{"color":"blue"}} >{output}</font>
{/* <form>
  <div class="form-group">
    <label for="catnm">Category Name:</label>
    <input type="text" class="form-control" value={catName} onChange={e => setCatName(e.target.value)}/>
  </div>
  <br/>
  
  <div class="form-group">
    <label for="file">Category Icon:</label>
    <input type="file" class="form-control" onChange={handleChange} />
  </div>
  <br/>
  <button onClick={handleSubmit} type="button" class="btn btn-danger">Add Category</button>
  <br/><br/>
</form> */}

<div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        {/* <h2 class="text-center text-dark mt-5">Login</h2> */}
        <div class="card my-5">

          <form class="card-body cardbody-color p-lg-5">

            <div class="mb-3">
            <label for="catnm">Category Name:</label>
            <input type="text" class="form-control" value={catName} onChange={e => setCatName(e.target.value)}/>
            </div>

            <div class="mb-3">
            <label for="file">Category Icon:</label>
            <input type="file" class="form-control" onChange={handleChange} />
            </div>

            <div class="text-center"><button onClick={handleSubmit} type="button" class="btn btn-success">Add Category</button></div>
            
          </form>
        </div>
      </div>
    </div>
  </div>


            </div>
        </div>
    </div>
    {/* About End */}
    </>
   );
}

export default Addcategory;