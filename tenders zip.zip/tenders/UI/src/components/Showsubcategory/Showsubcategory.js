import './Showsubcategory.css';
import { useState , useEffect } from 'react';
import axios from 'axios';
import { _categoryapiurl , _subcategoryapiurl } from '../../APIUrls';
import { Link , useParams} from 'react-router-dom'

function Showsubcategory() {

  const params = useParams();


  const [ subcategory , setSubCategoryDetails ] = useState([]);

  useEffect(()=>{
    var condition_obj={"catnm":params.catnm};
    axios.get(_subcategoryapiurl+"fetch",{
        params : { condition_obj : condition_obj }
    }).then((response)=>{
        setSubCategoryDetails(response.data.response_content);
    }).catch((error)=>{
        console.log(error);
    });    
  },[]);

  return (
    <>

{/* about start */}
<section class="about section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-12 text-center">
                            <h2 class="mb-5">Sub  Category <span>List &gt; &gt; { params.catnm }</span></h2>
                        </div>

                        <center>
                        <div id="main"> 
                        { 
                          subcategory.map((row)=>(
                            <Link to="">
                            <div class="part">
                              <img src={`../assets/uploads/subcaticons/${row.subcaticonnm}`} height="100" width="150" />
                              <br/>
                              <b>{row.subcatnm}</b>    
                            </div>
                            </Link>
                            )) 
                        }
                        </div>
                        </center>


                        
                    </div>
                </div>
            </section>
             {/* about end  */}

    </>
  );
}

export default Showsubcategory;
