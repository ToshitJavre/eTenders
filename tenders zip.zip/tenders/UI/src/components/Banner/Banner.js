import './Banner.css';
import { useState , useEffect } from 'react';

function Banner() {

    const [ BannerContent , setBannerContent ] = useState();

    useEffect(()=>{
        const token=localStorage.getItem("token");
        const role=localStorage.getItem("role");
        if(token !=undefined ){
            setBannerContent(<></>);
        }
        
        else{
            setBannerContent(    <>
      
                {/* carausal start */}
                <section class="slick-slideshow">   
                                <div class="slick-custom">
                                    <img src="./assets/images/slideshow/medium-shot-business-women-high-five.jpeg" class="img-fluid" alt="" />
                
                                    <div class="slick-bottom">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-6 col-10">
                                                    <h1 class="slick-title">Online Tender Site</h1>
                
                                                    <p class="lead text-white mt-lg-3 mb-lg-5">We Provide Solution On Your Tender.</p>
                
                                                    <a href="about.html" class="btn custom-btn">Learn more about us</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                
                                <div class="slick-custom">
                                    <img src="./assets/images/slideshow/team-meeting-renewable-energy-project.jpeg" class="img-fluid" alt="" />
                
                                    <div class="slick-bottom">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-6 col-10">
                                                    <h1 class="slick-title">Online Tender Site</h1>
                
                                                    <p class="lead text-white mt-lg-3 mb-lg-5">We Provide Solution On Your Tender.</p>
                
                                                    <a href="product.html" class="btn custom-btn">Explore products</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                
                                <div class="slick-custom">
                                    <img src="./assets/images/slideshow/two-business-partners-working-together-office-computer.jpeg" class="img-fluid" alt="" />
                
                                    <div class="slick-bottom">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-6 col-10">
                                                    <h1 class="slick-title">Online Tender Site</h1>
                
                                                    <p class="lead text-white mt-lg-3 mb-lg-5">We Provide Solution On Your Tender.</p>
                
                                                    <a href="contact.html" class="btn custom-btn">Work with us</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                
                            </section>
                            {/* carausal end */}
                
                    </>);
        }
    });


  return (
    <>
    { BannerContent}
    </>
  );
}

export default Banner;
