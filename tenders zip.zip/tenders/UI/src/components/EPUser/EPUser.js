import './EPUser.css';
import { useNavigate } from "react-router-dom";
import { useState , useEffect } from 'react';
import { _userapiurl } from '../../APIUrls';
import axios from 'axios';

function EPUser() {

    const navigate = useNavigate();

  const [ name, setName] = useState();
  const [ email, setEmail] = useState();
  const [ mobile, setMobile] = useState();
  const [ address, setAddress] = useState();
  const [ city, setCity] = useState();
  const [ gender , setGender ] = useState();
  const [ m, setM] = useState();
  const [ f, setF] = useState();

  const [ output, setOutput] = useState();
  
  useEffect(()=>{
    var condition_obj={"email":localStorage.getItem("email") };
    axios.get(_userapiurl+"fetch",{
        params : { condition_obj : condition_obj }
    }).then((response)=>{
      var userDetails = response.data.response_content[0];
      setName(userDetails.name);
      setEmail(userDetails.email);
      setMobile(userDetails.mobile);
      setAddress(userDetails.address);
      setCity(userDetails.city);
      if(userDetails.gender=="male")
        setM("checked");
       else
        setF("checked");
    }).catch((error)=>{
        console.log(error);
    });    
  },[]);

  const handlesubmit =()=>{
    var update_details={"condition_obj":{"email":email} ,"content_obj":{"name":name,"mobile":mobile,"address":address,"city":city,"gender":gender}};
      axios.patch(_userapiurl+"update",update_details).then((response)=>{
          alert("User profile edited successfully....");
          navigate("/adminhome");
      }).catch((error)=>{
        setOutput("Profile not change, Please try again...");
      });
  };

  return (
    <>

<section class="about section-padding">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="mb-5">Edit <span>Profile</span></h2>
                </div>
                <font color="blue">{output}</font>

            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" value={name} onChange={ e => setName(e.target.value)} />
                </div>
                <br/>

                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control" value={email} onChange={ e => setEmail(e.target.value)} />
                </div>
                <br/>

                <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="text" class="form-control" value={mobile} onChange={ e => setMobile(e.target.value)} />
                </div>
                <br/>

                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea rows="5" class="form-control" value={address} onChange={ e => setAddress(e.target.value)}></textarea>
                </div>
                <br/>

                <div class="form-group">
                    <label for="city">City</label>
                    <select class="form-control" value={city} onChange={ e => setCity(e.target.value)}>
                        <option>Select City</option>
                        <option>Indore</option>
                        <option>Bhopal</option>
                        <option>Ujjain</option>
                        <option>Dewas</option>
                    </select>
                </div>
                <br/>

                <div class="form-group">
                    <label for="gender">Gender: </label>
                    &nbsp;&nbsp;
                    Male <input type="radio" name='gender' checked={m} value="male" onChange={ e => setGender(e.target.value)} /> &nbsp;&nbsp;
                    Female <input type="radio" name='gender' checked={f} value="female" onChange={ e => setGender(e.target.value)} />
                </div>
                <br/>
  
                <button type="button" class="btn btn-warning" onClick={ ()=>handlesubmit() }>Update</button>
            </form>

            </div>
          </div>
    </section>

    </>
  );
}

export default EPUser;
