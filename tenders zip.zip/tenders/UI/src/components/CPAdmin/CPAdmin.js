import './CPAdmin.css';
import { useState } from 'react';
import { _userapiurl } from '../../APIUrls';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function CPAdmin() {

  const navigate = useNavigate();
  const [ opassword, setOldPassword] = useState();
  const [ npassword, setNewPassword] = useState();
  const [ cnpassword, setConfirmNewPassword] = useState();
  const [ output, setOutput] = useState();

  const handlesubmit=()=>{
    // var condition_obj={"email":localStorage.getItem("email"),"password":opass};
    axios.get(_userapiurl+"fetch?email="+localStorage.getItem("email")+"&password"+opassword,{
        // params : { condition_obj : condition_obj }
    }).then((response)=>{
        if(npassword==cnpassword)
        {
            var update_details={"condition_obj":{"email":localStorage.getItem("email")} ,"content_obj":{"password":cnpassword}};
            axios.patch(_userapiurl+"update",update_details).then((response)=>{
                alert("Password Changed successfully....");
                navigate("/adminhome");
                setOldPassword("");
                setNewPassword("");
                setConfirmNewPassword("");
            }).catch((error)=>{
              setOutput("Password not changed, please try again...")
            })
        }
        else
        {
            setOutput("New & confirm new password mismatch....");
            setNewPassword("");
            setConfirmNewPassword("");    
        }    
    }).catch((error)=>{
        setOutput("Invalid old password please try again....");
        setOldPassword("");    
    });
  };



  return (
    <>

{/* about start */}
<section class="about section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-12 text-center">
                            <h2 class="mb-5">TEND<span>ERS</span></h2>
                            <h2 class="mb-5">Change <span>Password</span></h2>
                        </div>

                        <form>

                
                <div class="form-group">
                    <label for="opwd">Old Password</label>
                    <input type="password" class="form-control" value={opassword} onChange={ e => setOldPassword(e.target.value)} />
                </div>
                <br/>

                <div class="form-group">
                    <label for="npwd">New Password</label>
                    <input type="password" class="form-control" value={npassword} onChange={ e => setNewPassword(e.target.value)} />
                </div>
                
                <br/>
                <div class="form-group">
                    <label for="cnpwd">Confirm New Password</label>
                    <input type="password" class="form-control" value={cnpassword} onChange={ e => setConfirmNewPassword(e.target.value)} />
                </div>
                <br/>

                
                <button type="button" class="btn btn-success" onClick={ ()=>handlesubmit() }>Submit</button>
            </form>


                    
                    </div>
                </div>
            </section>
             {/* about end  */}

    </>
  );
}

export default CPAdmin;
