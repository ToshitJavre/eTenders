import './Adminhome.css';

function Adminhome() {
  return (
    <>

{/* about start */}
<section class="about section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-12 text-center">
                            <h2 class="mb-5">Admin <span>Panel</span></h2>
                        </div>

                    
                    </div>
                </div>
            </section>
             {/* about end  */}

    </>
  );
}

export default Adminhome;
