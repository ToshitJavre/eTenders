import './Showcategory.css';
import { useState , useEffect } from 'react';
import axios from 'axios';
import { _categoryapiurl , _subcategoryapiurl } from '../../APIUrls';
import { Link } from 'react-router-dom';

function Showcategory() {


  const [ category , setCategoryDetails ] = useState([]);

  useEffect(()=>{
    axios.get(_categoryapiurl+"fetch").then((response)=>{
        setCategoryDetails(response.data.response_content);
    }).catch((error)=>{
        console.log(error);
    });    
  },[]); 

  return (
    <>

{/* about start */}
<section class="about section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-12 text-center">
                            <h2 class="mb-5">Category <span>List &gt; &gt;</span></h2>
                        </div>

                        <center>
                        <div id="main"> 
                        { 
                          category.map((row)=>(
                            <Link to={`/showsubcategory/${row.catnm}`}>
                            <div class="part">
                              <img src={`./assets/uploads/caticons/${row.caticonnm}`} height="100" width="150" />
                              <br/>
                              <b>{row.catnm}</b>    
                            </div>
                            </Link>
                            )) 
                        }
                        </div>
                        </center>


                        
                    </div>
                </div>
            </section>
             {/* about end  */}

    </>
  );
}

export default Showcategory;
