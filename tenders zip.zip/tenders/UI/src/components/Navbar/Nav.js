import './Nav.css';
import { Link } from 'react-router-dom';
import { useState , useEffect } from 'react';
import Auth from '../AuthComponent/Auth';

function Nav() {

    const [ NavContent , setNavContent ] = useState();

    useEffect(()=>{
        const token=localStorage.getItem("token");
        const role=localStorage.getItem("role");
        if(token!=undefined && role=="admin"){
            setNavContent(<>
                <nav class="navbar navbar-expand-lg">
                                <div class="container">
                                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                        <span class="navbar-toggler-icon"></span>
                                    </button>
                
                                    <a class="navbar-brand" href="index.html">
                                        <strong><span>TENDERS</span></strong>
                                    </a>
                
                                    <div class="d-lg-none">
                                        <a href="sign-in.html" class="bi-person custom-icon me-3"></a>
                
                                        <a href="product-detail.html" class="bi-bag custom-icon"></a>
                                    </div>
                
                                    <div class="collapse navbar-collapse" id="navbarNav">
                                        <ul class="navbar-nav mx-auto">
                                            <li class="nav-item">
                                                <a class="nav-link active"><Link to='/admin'>Admin Home</Link></a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link"><Link to='/manageusers'>Manage Users</Link></a>
                                            </li>

                                            <li class="nav-item">
                                            <div class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Manage Category</a>
                                                    <div class="dropdown-menu m-0">
                                                        <a class="dropdown-item"><Link to="/addcategory">Add Category</Link></a>
                                                        <a class="dropdown-item"><Link to="/addsubcategory">Add Sub Category</Link></a>
                                                    </div>
                                            </div>
                                            </li>

                                            <li class="nav-item">
                                            <div class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Settings</a>
                                                    <div class="dropdown-menu m-0">
                                                        <a class="dropdown-item"><Link to="/epadmin">Edit Profile</Link></a>
                                                        <a class="dropdown-item"><Link to="/cpadmin">Change Password</Link></a>
                                                        <a class="dropdown-item"><Link to='/logout'>Logout</Link></a>
                                                    </div>
                                            </div>
                                            </li>
                                
                                        </ul>
                
                                        <div class="d-none d-lg-block">
                                            <a href="sign-in.html" class="bi-person custom-icon me-3"></a>
                
                                            <a href="product-detail.html" class="bi-bag custom-icon"></a>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                    </>);
        }
        
        else if(token!=undefined && role=="user"){
            setNavContent(<>
                <nav class="navbar navbar-expand-lg">
                                <div class="container">
                                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                        <span class="navbar-toggler-icon"></span>
                                    </button>
                
                                    <a class="navbar-brand" href="index.html">
                                        <strong><span>TENDERS</span></strong>
                                    </a>
                
                                    <div class="d-lg-none">
                                        <a href="sign-in.html" class="bi-person custom-icon me-3"></a>
                
                                        <a href="product-detail.html" class="bi-bag custom-icon"></a>
                                    </div>
                
                                    <div class="collapse navbar-collapse" id="navbarNav">
                                         <ul class="navbar-nav mx-auto">
                                            <li class="nav-item">
                                                <a class="nav-link active"><Link to='/user'>User Home</Link></a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link "><Link to='/showcategory'>Show Tendes</Link></a>
                                            </li>

                                            <li class="nav-item">
                                            <div class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Settings</a>
                                                    <div class="dropdown-menu m-0">
                                                        <a class="dropdown-item"><Link to="/epuser">Edit Profile</Link></a>
                                                        <a class="dropdown-item"><Link to="/cpuser">Change Password</Link></a>
                                                        <a class="dropdown-item"><Link to='/logout'>Logout</Link></a>
                                                    </div>
                                            </div>
                                            </li>



{/*                 
                                            <li class="nav-item">
                                                <a class="nav-link"><Link to='/logout'>Logout</Link></a>
                                            </li>*/}
                                        </ul> 



                                        <div class="d-none d-lg-block">
                                            <a href="sign-in.html" class="bi-person custom-icon me-3"></a>
                
                                            <a href="product-detail.html" class="bi-bag custom-icon"></a>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                    </>);
        }
        
        else{
            setNavContent(<>
                <nav class="navbar navbar-expand-lg">
                                <div class="container">
                                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                        <span class="navbar-toggler-icon"></span>
                                    </button>
                
                                    <a class="navbar-brand" href="index.html">
                                        <strong><span>TENDERS</span></strong>
                                    </a>
                
                                    <div class="d-lg-none">
                                        <a href="sign-in.html" class="bi-person custom-icon me-3"></a>
                
                                        <a href="product-detail.html" class="bi-bag custom-icon"></a>
                                    </div>
                
                                    <div class="collapse navbar-collapse" id="navbarNav">
                                        <ul class="navbar-nav mx-auto">
                                            <li class="nav-item">
                                                <a class="nav-link active"><Link to='/'>Home</Link></a>
                                            </li>
                
                                            <li class="nav-item">
                                                <a class="nav-link"><Link to='/about'>About</Link></a>
                                            </li>
                
                                            <li class="nav-item">
                                                <a class="nav-link"><Link to='/contact'>Contact</Link></a>
                                            </li>
                
                                            <li class="nav-item">
                                                <a class="nav-link"><Link to='/service'>Service</Link></a>
                                            </li>
                
                                            <li class="nav-item">
                                                <a class="nav-link"><Link to='/register'>Register</Link></a>
                                            </li>
                
                                            <li class="nav-item">
                                                <a class="nav-link"><Link to='/login'>Login</Link></a>
                                            </li>
                                        </ul>
                
                                        <div class="d-none d-lg-block">
                                            <a href="sign-in.html" class="bi-person custom-icon me-3"></a>
                
                                            <a href="product-detail.html" class="bi-bag custom-icon"></a>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                    </>);
        }
    });

  return (
    <>
    <Auth />
    { NavContent } 
    </>
  );
}

export default Nav;
