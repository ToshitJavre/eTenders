import './Manageuser.css';
import { useState , useEffect } from 'react';
import { _userapiurl } from '../../APIUrls';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Manageusers() {

  const navigate = useNavigate();  
  const [ users , setUserDetails ] = useState([]);

  useEffect(()=>{
    var condition_obj={"role":"user"};
    axios.get(_userapiurl+"fetch",{
        params : { condition_obj : condition_obj }
    }).then((response)=>{
        setUserDetails(response.data.response_content);
    }).catch((error)=>{
        console.log(error);
    });    
  });

  const changestatususer=(_id,s)=>{
    if(s=="verify")
    {
      var update_details={"condition_obj":{"_id":_id} ,"content_obj":{"status":1}};
      axios.patch(_userapiurl+"update",update_details).then((response)=>{
          alert("User verified successfully....");
          navigate("/manageusers");
      });
    }
    else if(s=="block")
    {
      var update_details={"condition_obj":{"_id":_id} ,"content_obj":{"status":0}};
      axios.patch(_userapiurl+"update",update_details).then((response)=>{
          alert("User blocked successfully....");
          navigate("/manageusers");
      });
    }    
    else
    {
      var delete_details={"data":{"condition_obj":{"_id":_id}}};
      axios.delete(_userapiurl+"delete",delete_details).then((response)=>{
          alert("User deleted successfully....");
          navigate("/manageusers");
      });
    }
  };





  return (
    <>

<section class="about section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-12 text-center">
                          <h2 class="mb-5">Welcome  To <span>TENDERS</span></h2>
                            <h2 class="mb-5">Manage <span>Users</span></h2>
                        </div>

                        
                        <table class="text-center table table-bordered">
                        <thead className="bg-dark text-white">
                          <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>Gender</th>
                            <th>Info</th>
                            <th>Status</th>
                            <th>Action</th>
                          </tr>
                          </thead>
                          <tbody className="tbody-light border-dark">

                          {
                            users.map((row)=>(
                              <tr>
                                <td>{row._id}</td>
                                <td>{row.name}</td>    
                                <td>{row.email}</td>
                                <td>{row.mobile}</td>
                                <td>{row.address}</td>
                                <td>{row.city}</td>
                                <td>{row.gender}</td>
                                <td>{row.info}</td>
                                <td>
        
                                  {row.status==1?<font color="green">Verified</font>:<font color="orange">Blocked</font>}    
                                </td>
                                <td>
                                  {row.status==1?<font onClick={()=> changestatususer(row._id,'block')} color="blue">Change Status</font>:<font onClick={()=> changestatususer(row._id,'verify')} color="blue">Change Status</font>}
                                    <br/>
                                  <font onClick={()=> changestatususer(row._id,'delete')} color="red">Delete</font>
                                </td>
                              </tr>   
 ))    
}
</tbody>


                        </table>

                    
                    </div>
                </div>
            </section>

    </>
  );
}

export default Manageusers;
