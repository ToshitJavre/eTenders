import './Login.css';
import { useState } from 'react';
import { _userapiurl } from '../../APIUrls';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Login() {

    const navigate = useNavigate();
    const [ email, setEmail] = useState();
    const [ password, setPassword] = useState();
    const [ output, setOutput] = useState();

    const handlesubmit=()=>{
        const userDetails = {"email":email, "password":password,};
        
        axios.post(_userapiurl+"login",userDetails).then((response)=>{
            const obj = response.data;
            const user = obj.user;
            localStorage.setItem("token",obj.token);
            localStorage.setItem("_id",user._id);
            localStorage.setItem("name",user.name);
            localStorage.setItem("email",user.email);
            localStorage.setItem("mobile",user.mobile);
            localStorage.setItem("address",user.address);
            localStorage.setItem("city",user.city);
            localStorage.setItem("gender",user.gender);
            localStorage.setItem("info",user.info);
            localStorage.setItem("role",user.role);
    
            (user.role=="admin")?navigate("/admin"):navigate("/user");
            
        }).catch((error)=>{
            setOutput("Invalid user or verify your account...");
            setEmail("");
            setPassword("");
        });

    };


  return (
    <>

{/* about start */}
<section class="about section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-12 text-center">
                            <h2 class="mb-5">Log<span>in</span></h2>
                        </div>

                        <font color="blue">{output}</font>

            <form>

                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control" value={email} onChange={ e => setEmail(e.target.value)} />
                </div>
                <br/>

                <div class="form-group">
                    <label for="pwd">Password</label>
                    <input type="password" class="form-control" value={password} onChange={ e => setPassword(e.target.value)} />
                </div>
                <br/>

                
                <button type="button" class="btn btn-success" onClick={ ()=>handlesubmit() }>Submit</button>
            </form>


                    </div>
                </div>
            </section>


             {/* about end  */}

    </>
  );
}

export default Login;
